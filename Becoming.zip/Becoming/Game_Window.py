"""
Author: Meriebhel Diaz-Herrera
Description: Manages scene progression, user choices, and corruption tracking
             for the Becoming horror narrative.
"""

import tkinter as tk


class GameWindow(tk.Frame):
    """
    The game window frame that handles narrative scenes and tracks corruption level.
    """

    def __init__(self, parent, controller):
        super().__init__(parent, bg="#0f0f0f")
        self.controller = controller

        # Initialize game state variables
        # Tracks current scene
        self.scene_number = 1
        # Tracks psychological corruption
        self.corruption_level = 0

        # Scene Text Label
        self.scene_text = tk.Label(
            self,
            text="",
            wraplength=700,
            justify="center",
            font=("Helvetica", 14),
            bg="#0f0f0f",
            fg="#e6e6e6"
        )
        self.scene_text.pack(pady=20)

        # Choice Buttons
        self.choice_a_button = tk.Button(
            self,
            text="",
            command=self.choice_a,
            bg="#1c1c1c",
            fg="#e6e6e6",
            activebackground="#2a2a2a"
        )
        self.choice_a_button.pack(pady=5)

        self.choice_b_button = tk.Button(
            self,
            text="",
            command=self.choice_b,
            bg="#1c1c1c",
            fg="#e6e6e6",
            activebackground="#2a2a2a"
        )
        self.choice_b_button.pack(pady=5)

        # Exit Button
        exit_button = tk.Button(
            self,
            text="Exit",
            command=controller.quit,
            bg="#1c1c1c",
            fg="#e6e6e6",
            activebackground="#2a2a2a"
        )
        exit_button.pack(pady=10)

        # Load first scene
        self.update_scene()

    # ========================
    # Scene Management
    # ========================

    def update_scene(self):
        """
        The function updates scene text and button labels based on the current scene number.
        """

        if self.scene_number == 1:
            self.scene_text.config(
                text="You wake to the sound of your bedroom window sliding open.\n"
                     "A gloved hand clamps over your mouth before you can scream."
            )
            self.choice_a_button.config(text="Fight back")
            self.choice_b_button.config(text="Freeze")

        elif self.scene_number == 2:
            self.scene_text.config(
                text="Morning comes. No signs of forced entry.\n"
                     "The window is locked. The room untouched."
            )
            self.choice_a_button.config(text="Report it")
            self.choice_b_button.config(text="Stay silent")

        elif self.scene_number == 3:
            self.scene_text.config(
                text="That night, you see something tall standing at the tree line.\n"
                     "It does not move. It only watches."
            )
            self.choice_a_button.config(text="Look directly at it")
            self.choice_b_button.config(text="Close the blinds")

        elif self.scene_number == 4:
            self.scene_text.config(
                text="Your reflection seems delayed.\n"
                     "It tilts its head a second after you do."
            )
            self.choice_a_button.config(text="Touch the mirror")
            self.choice_b_button.config(text="Step back")

        else:
            # Move to ending
            self.controller.frames["EndingWindow"].set_ending(self.corruption_level)
            self.controller.show_frame("EndingWindow")

    # ========================
    # Choice Callbacks
    # ========================

    def choice_a(self):
        """
        Handles logic for first choice button.
        """

        if self.scene_number == 1:
            self.corruption_level += 1
        elif self.scene_number == 2:
            pass
        elif self.scene_number == 3:
            self.corruption_level += 1
        elif self.scene_number == 4:
            self.corruption_level += 1

        self.scene_number += 1
        self.update_scene()

    def choice_b(self):
        """
        Handles logic for second choice button.
        """

        if self.scene_number == 1:
            pass
        elif self.scene_number == 2:
            self.corruption_level += 1
        elif self.scene_number == 3:
            pass
        elif self.scene_number == 4:
            pass

        self.scene_number += 1
        self.update_scene()