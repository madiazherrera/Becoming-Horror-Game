"""
Author: Meriebhel Diaz-Herrera
Description: Displays the main menu and handles user name input.
"""

import tkinter as tk
from tkinter import messagebox
from Input_Check import validate_name


class MainMenu(tk.Frame):
    """
    The main menu frame that allows user to enter their name and start the game.
    """

    def __init__(self, parent, controller):
        super().__init__(parent, bg="#0f0f0f")
        self.controller = controller

        # Title Label
        title_label = tk.Label(
            self,
            text="Becoming",
            font=("Helvetica", 28),
            bg="#0f0f0f",
            fg="#e6e6e6"
        )
        title_label.pack(pady=20)

        # Instructions Label
        instruction_label = tk.Label(
            self,
            text="Enter your name to begin.",
            font=("Helvetica", 14),
            bg="#0f0f0f",
            fg="#9e9e9e"
        )
        instruction_label.pack(pady=10)

        # Name Entry Field
        self.name_entry = tk.Entry(self, font=("Helvetica", 14))
        self.name_entry.pack(pady=10)

        # Start Button
        start_button = tk.Button(
            self,
            text="Start",
            command=self.start_game,
            bg="#1c1c1c",
            fg="#e6e6e6",
            activebackground="#2a2a2a"
        )
        start_button.pack(pady=10)

        # Exit Button
        exit_button = tk.Button(
            self,
            text="Exit",
            command=controller.quit,
            bg="#1c1c1c",
            fg="#e6e6e6",
            activebackground="#2a2a2a"
        )
        exit_button.pack(pady=5)

    def start_game(self):
        """
        The callback function for Start button.
        It validates user input before proceeding.
        """

        name = self.name_entry.get()

        valid, message = validate_name(name)

        if not valid:
            messagebox.showerror("Input Error", message)
        else:
            self.controller.player_name = name
            self.controller.show_frame("GameWindow")