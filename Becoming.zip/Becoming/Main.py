"""
Author: Meriebhel Diaz-Herrera
Description: Entry point for the Becoming horror GUI application.
             Controls frame switching between different windows.
"""

import tkinter as tk
from Main_Menu import MainMenu
from Game_Window import GameWindow
from Ending_Window import EndingWindow


class BecomingApp(tk.Tk):
    """
    The main application class that manages and switches between frames (windows).
    """

    def __init__(self):
        super().__init__()

        self.title("Becoming: An Interactive Horror Experience")
        self.geometry("800x600")
        self.configure(bg="#0f0f0f")

        # Store player name globally
        self.player_name = ""

        # Container frame to hold all other frames
        container = tk.Frame(self, bg="#0f0f0f")
        container.pack(fill="both", expand=True)

        self.frames = {}

        # Initialize frames
        for F in (MainMenu, GameWindow, EndingWindow):
            frame = F(container, self)
            self.frames[F.__name__] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("MainMenu")

    def show_frame(self, frame_name):
        """
        Brings the selected frame to the front.
        """
        frame = self.frames[frame_name]
        frame.tkraise()


if __name__ == "__main__":
    app = BecomingApp()
    app.mainloop()