"""
Author: Meriebhel Diaz-Herrera
Description: Contains validation and helper functions used across the application.
"""

def validate_name(name):
    """
    The function that validates the player's name input.
    It ensures the name is not empty, contains only letters, and is under 20 characters.
    """

    if name.strip() == "":
        return False, "Name cannot be empty."

    if not name.isalpha():
        return False, "Name must contain letters only."

    if len(name) > 20:
        return False, "Name must be under 20 characters."

    return True, ""