"""
Author: Meriebhel Diaz-Herrera
Description: Displays the final transformation scene based on corruption level.
"""

import tkinter as tk


class EndingWindow(tk.Frame):
    """
    The ending window frame that displays transformation ending.
    """

    def __init__(self, parent, controller):
        super().__init__(parent, bg="#0f0f0f")
        self.controller = controller

        # Ending text label
        self.ending_text = tk.Label(
            self,
            text="",
            wraplength=700,
            justify="center",
            font=("Helvetica", 14),
            bg="#0f0f0f",
            fg="#e6e6e6"
        )
        self.ending_text.pack(pady=20)

        # Restart Button
        restart_button = tk.Button(
            self,
            text="Restart",
            command=self.restart_game,
            bg="#1c1c1c",
            fg="#e6e6e6",
            activebackground="#2a2a2a"
        )
        restart_button.pack(pady=5)

        # Exit Button
        exit_button = tk.Button(
            self,
            text="Exit",
            command=controller.quit,
            bg="#1c1c1c",
            fg="#e6e6e6",
            activebackground="#2a2a2a"
        )
        exit_button.pack(pady=5)

    def set_ending(self, corruption_level):
        """
        The function that determines which ending text to display.
        """

        name = self.controller.player_name

        if corruption_level >= 3:
            text = (
                "You lean closer to the mirror.\n"
                "The figure smiles before you do.\n\n"
                f"That isn't your name anymore, {name}.\n"
                "You were never meant to stay the same."
            )
        else:
            text = (
                "You try to pull away.\n"
                "But your reflection doesn’t follow.\n\n"
                f"That isn't your name anymore, {name}.\n"
                "Something else has taken root."
            )

        self.ending_text.config(text=text)

    def restart_game(self):
        """
        The function resets game state and returns to main menu.
        """

        # Reset game variables
        game_frame = self.controller.frames["GameWindow"]
        game_frame.scene_number = 1
        game_frame.corruption_level = 0
        game_frame.update_scene()

        self.controller.show_frame("MainMenu")